package sample.java8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Test {
    public static void main(String[] args) {
        Thread thread = new Thread(() -> System.out.println("In other thread"));//lambda
        thread.start();
        System.out.println("In main thread");
        List<Integer> number= Arrays.asList(1,5,7,834,78);

        number.forEach(num -> System.out.println(num));//Lambda Functions
        number.forEach(System.out::println);//Internal Iterator
        number.stream().map(num -> String.valueOf(num));
        List<String> numberStrings=number.stream()
                .filter(num1->num1>5)
                .filter(num5->num5%2==0)
                .map(String::valueOf)
                .collect(Collectors.toList());
        System.out.println(numberStrings);
    }
}
