package sample;

public class Total {
    public static void main(String[] args) {
        Car b1=new BMW();
        Car e=new Engine();
        b1.show();
        e.show();

    }
}
