package sample;

public class Strings {
    public static void main(String[] args) {
        String s1="Hello";//Strings are created in the string constant pool
        String s2=new String("Hello");//created in the heap memory
        System.out.println(s1==s2);
        String s3="Hello";
        System.out.println(s1==s3);
        String s4=new String("Hello").intern();//By intern keyword it check the string s4 in string constant pool
        System.out.println(s1==s4);
        String s5=null;
        System.out.println(s5.equals(s1));//if we check null with any strings it give the NULL POINTER EXCEPTION
    }
}
