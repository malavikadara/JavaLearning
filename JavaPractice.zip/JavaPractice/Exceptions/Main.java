package sample;

import java.io.FileNotFoundException;

public class Main {
    public static void main(String[] args) {
        Banana f=new Banana();
        try {
            System.out.println(f.eat());
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}
