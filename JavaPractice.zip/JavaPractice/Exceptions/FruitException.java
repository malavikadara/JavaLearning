package sample;

public class FruitException extends RuntimeException{

    public FruitException(String message, Throwable cause) {
        super(message, cause);
    }

    public FruitException(String message) {
        super(message);
    }
}
