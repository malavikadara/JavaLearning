package sample;

import java.io.IOException;

public class Fruit {
    public Number eat() throws IOException
    {
        System.out.println("Eat");
        return null;
    }
}
