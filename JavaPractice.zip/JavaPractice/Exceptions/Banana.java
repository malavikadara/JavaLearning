package sample;

import java.io.FileNotFoundException;

public class Banana extends Fruit{
    public Integer eat() throws FileNotFoundException
    {
        System.out.println("In Banana Class");
        return null;
    }
}
