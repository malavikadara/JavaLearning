package sample.Collection;

import java.util.LinkedHashSet;
import java.util.Set;

public class Linked_HashSet {
    public static void main(String[] args) {
        Set<Employee> Linked=new LinkedHashSet<>();
        Linked.add(new Employee("malavika","41863"));
        Linked.add(new Employee("dara","41966"));
        Linked.add(new Employee("madhu","41863"));
        System.out.println(Linked);

    }
}
