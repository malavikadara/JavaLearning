package sample.Collection;

import java.util.HashSet;
import java.util.Set;

public class Set_Class {
    public static void main(String[] args) {
        Set<Employee> emp=new HashSet<>();
        emp.add(new Employee("malavika","41863"));
        emp.add(new Employee("dara","41568"));
        emp.add(new Employee("madhu","41789"));
        System.out.println(emp);
        Employee emp1=new Employee("Geethika","100003");
        Employee emp2=new Employee("Geethika","100003");
        if(emp1.equals(emp2))
        {
            System.out.println("Both are equal");
        }
        System.out.println(emp1.hashCode());
     System.out.println(emp2.hashCode());


    }
}
