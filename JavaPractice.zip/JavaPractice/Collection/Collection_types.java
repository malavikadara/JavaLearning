package sample.Collection;

import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Collection_types {
    public static void main(String[] args) {
        List<Employee> employee = new ArrayList<>();

        employee.add(new Employee("Malavika", "63"));
        employee.add(new Employee("Dara", "54"));
        Collections.sort(employee);
        /*for(int i=0;i< employee.size();i++)
        {
            System.out.println(employee.get(i));
        }*/
        System.out.println(employee);



    }

}
