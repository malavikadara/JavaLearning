package sample.Collection;

import java.util.Set;
import java.util.TreeSet;

public class Tree_HashSet {
    public static void main(String[] args) {
        Set<Employee> emp=new TreeSet<>(new EmployeeIdComparator());
       emp.add(new Employee("malavika","41863"));
        emp.add(new Employee("dara","41966"));
        emp.add(new Employee("madhu","41672"));
        System.out.println(emp);
    }
}
