package sample.Collection;

import java.util.HashMap;
import java.util.Map;

public class Hashmap {
    public static void main(String[] args) {
        Map<Employee,String> employeeStringMap=new HashMap<>();
        employeeStringMap.put(new Employee("malavika","41863"),"hashCode");
        employeeStringMap.put(new Employee("dara","41567"),"hash");
        employeeStringMap.put(new Employee("madhu","41963"),"Code");
        employeeStringMap.put(new Employee("vani","41363"),"vvvjccgucc");
        System.out.println(employeeStringMap);
        for (Employee key : employeeStringMap.keySet()) {
            System.out.println(key);
        }
        for (String key : employeeStringMap.values()) {
            System.out.println(key);
        }

    }
}
